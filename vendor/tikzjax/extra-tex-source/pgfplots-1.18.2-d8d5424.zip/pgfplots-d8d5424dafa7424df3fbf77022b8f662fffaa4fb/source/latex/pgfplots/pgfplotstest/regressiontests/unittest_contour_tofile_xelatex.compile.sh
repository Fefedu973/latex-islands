xelatex -shell-escape $@
