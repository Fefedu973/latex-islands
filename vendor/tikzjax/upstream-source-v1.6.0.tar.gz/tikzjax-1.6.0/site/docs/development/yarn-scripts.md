# Yarn scripts

TikZJax standardizes development around **Yarn 4.17.1**.

The scripts below are defined in `package.json`.

## Main commands

| Command | Purpose |
| --- | --- |
| `yarn dev` | Incrementally synchronize the local TikZJax vendor, then start the MkDocs documentation. |
| `yarn dev:lan` | Same workflow, with MkDocs exposed on `0.0.0.0:8000`. |
| `yarn playground` | Start the standalone Webpack development playground. |
| `yarn pg` | Short alias for `yarn playground`. |
| `yarn playground:lan` | Start the Webpack playground on the LAN. |
| `yarn pg:lan` | Short alias for `yarn playground:lan`. |
| `yarn build` | Build production bundles and regenerate runtime assets. |
| `yarn build:full` | Alias of the complete normal build. |
| `yarn build:full:check` | Clean, rebuild everything, then validate `dist/`. |
| `yarn bfc` | Short alias for `yarn build:full:check`. |
| `yarn zip` | Create a complete development ZIP, including the four Web2js runtime artifacts when present. |

## Vendor commands

| Command | Purpose |
| --- | --- |
| `yarn vendor:sync` | Incrementally build and synchronize explicitly configured vendors. |
| `yarn vendor:check` | Diagnose source state, `dist/`, vendor synchronization, and Web2js handoff files. |
| `yarn vendor:clean` | Remove generated vendor files and incremental vendor state. |

A forced vendor rebuild is available when diagnosing stale state:

```bash
yarn vendor:sync --force
```

Normal development should **not** use `--force`; the incremental detection exists specifically to avoid unnecessary builds.

## Build internals

| Command | Purpose |
| --- | --- |
| `yarn clean` | Remove `dist/`. |
| `yarn build:core` | Run the production Webpack build. |
| `yarn build:assets` | Install/generate fonts and regenerate TeX runtime files. |
| `yarn build:dev` | Run a non-server development Webpack build. |
| `yarn validate:dist` | Validate required distribution files. |
| `yarn install-fonts` | Run `installFonts.mjs`. |
| `yarn gen-tex-files` | Run `genTexFiles.js`. |

## Quality commands

| Command | Purpose |
| --- | --- |
| `yarn lint` | Run ESLint. |
| `yarn lint:fix` | Run ESLint with automatic fixes. |
| `yarn format` | Format the project with Prettier. |
| `yarn javascript:check` | JavaScript lint check. |
| `yarn ci` | Run linting and the complete checked build. |
| `yarn check` | Alias for the CI check. |

## Deployment helper

```bash
yarn deploy:cdn "commit message"
```

This uses `deployToCdn.js` for the existing CDN deployment workflow. Use it only after the local build and release state have been validated.

## Recommended command by task

If you are editing documentation only:

```bash
yarn dev
```

If you are editing TikZJax runtime source:

```bash
yarn bfc
yarn dev
```

If you are editing Web2js:

```bash
cd ../web2js
yarn bfc
yarn deploy:tikzjax

cd ../tikzjax
yarn bfc
yarn dev
```
