# Development overview

This section is the **canonical development documentation** for `rod2ik/TikZJax`.

TikZJax uses **Yarn 4.17.1**, Webpack, MkDocs, a local incremental vendor workflow, and a sibling `web2js` project for the browser TeX runtime.

## First setup

Enable Corepack once, then install the project dependencies:

```bash
corepack enable
yarn install
```

The project pins Yarn through `package.json`:

```text
packageManager: yarn@4.17.1
```

and uses the classic `node_modules` linker through `.yarnrc.yml` for compatibility with the existing Webpack toolchain.

For reproducible installs after the lockfile exists, use:

```bash
yarn install --immutable
```

## Daily development

There are two intentionally separate development environments.

### Documentation site

```bash
yarn dev
```

This command:

1. runs the incremental vendor synchronization;
2. rebuilds TikZJax only if configured build inputs changed;
3. synchronizes `dist/` to `site/overrides/vendor/tikzjax/` only when needed;
4. starts MkDocs with the local TikZJax vendor.

Documentation-only changes do **not** rebuild TikZJax.

For another device on the LAN:

```bash
yarn dev:lan
```

MkDocs is then exposed on `0.0.0.0:8000`.

### Webpack playground

```bash
yarn playground
```

Short alias:

```bash
yarn pg
```

For LAN access:

```bash
yarn playground:lan
# or
yarn pg:lan
```

The playground is useful for isolated runtime development. The MkDocs site is the preferred environment for validating real documentation integration.

## Normal Web2js → TikZJax workflow

When Web2js changes:

```bash
cd ../web2js
yarn bfc
yarn deploy:tikzjax

cd ../tikzjax
yarn bfc
yarn dev
```

`yarn deploy:tikzjax` updates the TikZJax runtime handoff, including the four Web2js runtime artifacts and the generated TeX file manifest.

See [Web2js integration](web2js-integration.md) for the complete data flow.

## Development map

```text
web2js/
   │
   │ yarn deploy:tikzjax
   ▼
tikzjax/
   ├── tex.wasm
   ├── tex.wasm.gz
   ├── core.dump
   ├── core.dump.gz
   └── tex_files.json
          │
          │ yarn build / yarn bfc
          ▼
        dist/
          │
          │ yarn vendor:sync
          ▼
site/overrides/vendor/tikzjax/
          │
          │ yarn dev
          ▼
        MkDocs
```

## Where to go next

- [Yarn scripts](yarn-scripts.md) — complete command reference.
- [Vendor system](vendor-system.md) — whitelist, hashes, incremental rebuilds, and adding vendors.
- [Web2js integration](web2js-integration.md) — runtime artifacts and handoff workflow.
- [Documentation site](documentation-site.md) — MkDocs, local vendor mode, fenced blocks, and raw TikZ scripts.
- [Build and validation](build-validation.md) — build layers and validation commands.
- [Release workflow](release-workflow.md) — version, tag, GitHub Release, npm publication, and CDN deployment.
