# Build and validation

TikZJax separates the normal build, checked build, documentation development, and Webpack playground.

## Normal production build

```bash
yarn build
```

This runs:

```text
build:core
    → production Webpack bundles

build:assets
    → install/generate fonts
    → regenerate TeX runtime files
```

`yarn build:full` currently resolves to the same complete normal build.

## Complete checked build

Before considering a source change ready:

```bash
yarn bfc
```

This is the short alias for:

```bash
yarn build:full:check
```

which performs:

```text
clean
  ↓
build
  ↓
validate:dist
```

A successful run ends with the distribution validation reporting:

```text
DIST OK
```

## Distribution validation

`yarn validate:dist` verifies the expected generated distribution, including the main TikZJax bundle and required generated TeX runtime files.

The local vendor system performs an additional structural check through `requiredDist` before it copies `dist/` into the documentation vendor.

## Reproducible dependency check

After `yarn.lock` has been generated with Yarn 4:

```bash
yarn install --immutable
```

should complete without modifying the lockfile.

Use this before release when dependency reproducibility matters.

## JavaScript checks

```bash
yarn lint
yarn javascript:check
```

For the full CI-oriented check:

```bash
yarn ci
```

which runs linting followed by the complete checked build.

## Validation after Web2js changes

Recommended sequence:

```bash
cd ../web2js
yarn bfc
yarn deploy:tikzjax

cd ../tikzjax
yarn install --immutable
yarn bfc
yarn vendor:check
yarn dev
```

Then exercise representative documentation pages in the browser, especially package examples that depend on the regenerated TeX runtime.

## Development ZIP

```bash
yarn zip
```

The ZIP helper uses the Git file set plus the four Web2js runtime artifacts when they exist:

```text
tex.wasm
tex.wasm.gz
core.dump
core.dump.gz
```

This is intentional: those runtime files remain ignored by Git but are necessary when sharing the exact local state that was tested.
