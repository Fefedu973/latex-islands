/* License: GNU GPLv3+, Rodrigo Schwencke (Copyleft) */

window.MathJax = {
  loader: {
    load: [
      '[tex]/tagformat',
      '[tex]/colortbl',
      '[tex]/extpfeil',
      '[tex]/mathtools',
      '[tex]/empheq',
      '[tex]/cases',
      '[tex]/cancel',
      '[tex]/textmacros',
      '[tex]/bbox',
      '[tex]/physics',
      '[tex]/unicode'
    ]
  },

  startup: {
    /*
     * Material for MkDocs déclenche lui-même le rendu via document$.
     * Cela évite un premier rendu automatique suivi d'un second rendu.
     */
    typeset: false,

    pageReady: () => {
      // alert('Running MathJax');
      return MathJax.startup.defaultPageReady();
    }
  },

  /*
   * Police historique de MathJax 3.
   *
   * Cela évite l'utilisation de la police mathjax-newcm
   * et de ses plages de caractères chargées dynamiquement.
   */
  output: {
    font: 'mathjax-tex'
  },

  tex: {
    inlineMath: [
      ['$', '$'],
      ['\\(', '\\)']
    ],

    displayMath: [
      ['\\[', '\\]']
    ],

    processEscapes: true,
    processEnvironments: true,

    packages: {
      '[+]': [
        'tagformat',
        'colortbl',
        'extpfeil',
        'mathtools',
        'empheq',
        'cases',
        'cancel',
        'textmacros',
        'bbox',
        'physics',
        'unicode'
      ]
    },

    tags: 'ams',
    tagSide: 'right',

    macros: {
      // math-BlackboardBold
      m: ['{\\mathbb #1}', 1],

      // mathsCal
      mc: ['{\\mathcal #1}', 1],

      // Arrows
      imp: '{\\Rightarrow}',
      implique: '{\\Rightarrow}',
      iimp: '{\\Longrightarrow}',
      ssi: '{\\Leftrightarrow}',
      sssi: '{\\Longleftrightarrow}',

      RR: '{\\bf R}',
      divsym: '{\\mathbin{\\unicode{x00F7}}}',
      euro: ['{\\unicode \{0x20AC\}}'],
      leftouterjoin: ["\\mathbin{\\unicode{x27D5}}"],
      rightouterjoin: ["\\mathbin{\\unicode{x27D6}}"],
      fullouterjoin: ["\\mathbin{\\unicode{x27D7}}"],
      bold: ['{\\bf #1}', 1],

      // colors list reference:
      // https://www.w3schools.com/colors/colors_names.asp
      tcolor: ['{\\color\{#1\} #2}', 2],
      redcolor: ['{\\color\{red\} #1}', 1],
      bluecolor: ['{\\color\{blue\} #1}', 1],
      greencolor: ['{\\color\{green\} #1}', 1],
      purplecolor: ['{\\color\{purple\} #1}', 1],
      blackcolor: ['{\\color\{black\} #1}', 1],

      red: ['{\\color\{red\} #1}', 1],
      blue: ['{\\color\{blue\} #1}', 1],
      green: ['{\\color\{green\} #1}', 1],
      purple: ['{\\color\{purple\} #1}', 1],
      black: ['{\\color\{black\} #1}', 1],

      symbover: [
        '{\\displaystyle \\stackrel{\\mathclap{\\mbox{ #2 }}}{ #1 }}',
        2
      ],

      liminf: [
        '{\\displaystyle \\lim_\{#1\\to+\\infty\} #2}',
        2
      ],

      limninf: [
        '{\\displaystyle \\lim_\{n\\to+\\infty\} #1}',
        1
      ],

      limxinf: [
        '{\\displaystyle \\lim_\{x\\to+\\infty\} #1}',
        1
      ],

      limxminf: [
        '{\\displaystyle \\lim_\{x\\to-\\infty\} #1}',
        1
      ],

      limxa: [
        '{\\displaystyle \\lim_\{x\\to #1\} #2}',
        2
      ],

      // \displaystyle \lim_{x\to+\infty} x^2=+\infty$
      redbox: [
        '{\\bbox[5px, border: 2px solid red]\{#1\}}',
        1
      ],

      greenbox: [
        '{\\bbox[5px, border: 2px solid green]\{#1\}}',
        1
      ],

      bluebox: [
        '{\\bbox[5px, border: 2px solid blue]\{#1\}}',
        1
      ],

      purplebox: [
        '{\\bbox[5px, border: 2px solid purple]\{#1\}}',
        1
      ],

      blackbox: [
        '{\\bbox[5px, border: 2px solid black]\{#1\}}',
        1
      ],

      box: [
        '{\\bbox[5px, border: 2px solid #1] \{#2\}}',
        2
      ],

      enc: [
        '{\\bbox[5px, border: 2px solid #1] \{#2\}}',
        2
      ],

      simp: [
        '{\\cancel \{#1\}}',
        1
      ],

      vec: [
        '{\\overrightarrow \{#1\}}',
        1
      ],

      coord: [
        '{\\begin\{pmatrix\} #1 \\\\ #2 \\\\ \\end\{pmatrix\}}',
        2
      ],

      Coord: [
        '{\\begin{pmatrix} #1 \\\\ #2 \\\\ #3 \\end{pmatrix}}',
        3
      ],

      vertarrowbox: [
        '{\\begin\{array\}\{@\{\}c@\{\}\} #2 \\\\ \\left\\uparrow\\vcenter\{\\hrule height #1\}\\right.\\kern-\\nulldelimiterspace\\\\ \\makebox[0pt]\{\\scriptsize #3\} \\\\ \\end\{array\}}',
        3,
        '6ex'
      ],

      cotan: [
        '{\\text\{cotan \}\{#1\}}',
        1
      ],

      hey: [
        '{\\begin\{array\} \\\\ #1 & 2 \\\\ 3 & 4 \\\\ \\end\{array\}}',
        1
      ]
    },

    textmacros: {
      packages: {
        '[+]': ['bbox']
      }
    },

    /*
     * Configuration personnalisée des numéros d'équations.
     */
    tagformat: {
      tag: (n) => '(' + n + ')'
    }

    /*
     * Ancienne configuration SVG conservée en commentaire.
     *
     * svg: {
     *   fontCache: 'global'
     * }
     */
  }

  /*
   * Activer ces options revient à casser le code LaTeX
   * dans le menu-page situé à droite.
   *
   * options: {
   *   ignoreHtmlClass: ".*|",
   *   processHtmlClass: "arithmatex"
   * }
   */
};


/*
 * File d'attente des rendus MathJax.
 *
 * Elle empêche deux navigations Material rapprochées de lancer
 * deux opérations MathJax concurrentes.
 */
let mathJaxTypesetQueue = Promise.resolve();


document$.subscribe(({ body }) => {
  mathJaxTypesetQueue = mathJaxTypesetQueue
    /*
     * Attend que MathJax soit complètement initialisé.
     */
    .then(() => MathJax.startup.promise)

    .then(() => {
      /*
       * Lors d'une navigation très rapide, un nouveau document$
       * peut être émis avant le traitement du précédent.
       *
       * Dans ce cas, l'ancien body n'est plus présent dans le DOM :
       * il ne faut donc plus le traiter.
       */
      if (!body?.isConnected) {
        return;
      }

      /*
       * Oublie les expressions enregistrées pour la page précédente.
       */
      MathJax.typesetClear();

      /*
       * Recommence la numérotation des équations sur chaque page.
       */
      MathJax.texReset();

      /*
       * Ne traite que le contenu fourni par la nouvelle page Material.
       *
       * typesetPromise() est utilisé plutôt que typeset() afin de
       * prendre correctement en charge les opérations asynchrones.
       */
      return MathJax.typesetPromise([body]);
    })

    .catch((error) => {
      console.error('MathJax typesetting failed:', error);
    });
});