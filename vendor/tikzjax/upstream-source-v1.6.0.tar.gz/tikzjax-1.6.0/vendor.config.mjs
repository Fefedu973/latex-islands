// Only projects explicitly listed here are vendored. No parent directory is scanned.
export default {
    vendorDir: 'site/overrides/vendor',
    stateFile: '.cache/vendor-sync/state.json',
    projects: [
        {
            name: 'tikzjax',
            local: '.',
            dist: 'dist',
            build: {
                command: 'yarn',
                args: ['build']
            },
            inputs: [
                'src',
                'css',
                'assets/broken-image.svg',
                'assets/broken-image-degrade.svg',
                'assets/broken-image-emoji.svg',
                'assets/broken-image-epuree.svg',
                'assets/broken-image-esquisse.svg',
                'assets/broken-image-materielle.svg',
                'assets/broken-image-minimaliste.svg',
                'assets/broken-image-moderne.svg',
                'tex_files.json',
                'tikzlibraryarrows.meta.code.tex',
                'genTexFiles.js',
                'installFonts.mjs',
                'webpack.config.cjs',
                'package.json',
                'yarn.lock',
                'core.dump.gz',
                'tex.wasm.gz'
            ],
            inspectFiles: ['tex.wasm', 'tex.wasm.gz', 'core.dump', 'core.dump.gz'],
            requiredDist: [
                'tikzjax.js',
                'tikzjax.min.js',
                'run-tex.js',
                'run-tex.min.js',
                'fonts.css',
                'fonts.min.css',
                'fonts',
                'tex.wasm.gz',
                'core.dump.gz',
                'tex_files'
            ]
        }
    ]
};
