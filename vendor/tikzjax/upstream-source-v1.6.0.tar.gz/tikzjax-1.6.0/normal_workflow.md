# Normal Workflow

The canonical development documentation now lives in the MkDocs site under `site/docs/development/`.

## First setup

```bash
corepack enable
yarn install --immutable
```

TikZJax uses Yarn 4.17.1.

## Documentation development

```bash
yarn dev
```

For LAN/mobile testing:

```bash
yarn dev:lan
```

## Webpack playground

```bash
yarn playground
# short alias
yarn pg
```

For LAN access:

```bash
yarn playground:lan
# short alias
yarn pg:lan
```

## After Web2js changes

```bash
cd ../web2js
yarn bfc
yarn deploy:tikzjax

cd ../tikzjax
yarn bfc
yarn vendor:check
yarn dev
```

## Before a TikZJax release

```bash
yarn install --immutable
yarn bfc
yarn vendor:check
```

Then update `package.json`, commit/push, create the matching `v<version>` tag, and push the tag. The GitHub Release and npm publication workflows are tag-driven.

After the release state is validated, the existing CDN helper is:

```bash
yarn deploy:cdn "commit message"
```

## Detailed documentation

- `site/docs/development/index.md`
- `site/docs/development/yarn-scripts.md`
- `site/docs/development/vendor-system.md`
- `site/docs/development/web2js-integration.md`
- `site/docs/development/documentation-site.md`
- `site/docs/development/build-validation.md`
- `site/docs/development/release-workflow.md`
