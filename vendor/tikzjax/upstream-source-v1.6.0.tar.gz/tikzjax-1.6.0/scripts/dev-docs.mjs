#!/usr/bin/env node

import path from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(scriptDir, '..');
const siteDir = path.join(projectRoot, 'site');
const vendorScript = path.join(scriptDir, 'vendor-sync.mjs');
const lan = process.argv.includes('--lan');

const sync = spawnSync(process.execPath, [vendorScript, 'sync'], {
    cwd: projectRoot,
    env: process.env,
    stdio: 'inherit'
});

if (sync.error) {
    console.error(sync.error.message);
    process.exit(1);
}

if (sync.status !== 0) {
    process.exit(sync.status || 1);
}

const args = ['serve'];

if (lan) {
    args.push('-a', '0.0.0.0:8000');
}

console.log('');
console.log('Starting MkDocs with local TikZJax vendor assets...');

const mkdocs = spawn('mkdocs', args, {
    cwd: siteDir,
    env: {
        ...process.env,
        TIKZJAX_DOCS_ASSET_MODE: 'vendor'
    },
    stdio: 'inherit'
});

mkdocs.on('error', (error) => {
    console.error(`Unable to start MkDocs: ${error.message}`);
    process.exitCode = 1;
});

mkdocs.on('exit', (code, signal) => {
    if (signal) {
        process.kill(process.pid, signal);
        return;
    }

    process.exitCode = code || 0;
});
