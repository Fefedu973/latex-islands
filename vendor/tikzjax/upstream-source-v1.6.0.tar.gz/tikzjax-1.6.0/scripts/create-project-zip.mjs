#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(scriptDir, '..');
const packageJson = JSON.parse(fs.readFileSync(path.join(projectRoot, 'package.json'), 'utf8'));
const output = path.resolve(projectRoot, '..', `tikzjax-${packageJson.version}-project.zip`);
const runtimeArtifacts = ['tex.wasm', 'tex.wasm.gz', 'core.dump', 'core.dump.gz'];

const listed = spawnSync('git', ['ls-files', '--cached', '--others', '--exclude-standard'], {
    cwd: projectRoot,
    encoding: 'utf8'
});

if (listed.error) {
    throw listed.error;
}

if (listed.status !== 0) {
    process.stderr.write(listed.stderr || 'git ls-files failed.\n');
    process.exit(listed.status || 1);
}

const files = new Set(
    listed.stdout
        .split(/\r?\n/)
        .map((entry) => entry.trim())
        .filter(Boolean)
);

for (const artifact of runtimeArtifacts) {
    if (fs.existsSync(path.join(projectRoot, artifact))) {
        files.add(artifact);
    }
}

const sortedFiles = [...files].sort((a, b) => a.localeCompare(b));

if (sortedFiles.length === 0) {
    console.error('No project files were found.');
    process.exit(1);
}

fs.rmSync(output, { force: true });

const zip = spawnSync('zip', ['-9', '-q', '-y', output, '-@'], {
    cwd: projectRoot,
    input: `${sortedFiles.join('\n')}\n`,
    encoding: 'utf8'
});

if (zip.error) {
    throw zip.error;
}

if (zip.status !== 0) {
    process.stderr.write(zip.stderr || 'zip failed.\n');
    process.exit(zip.status || 1);
}

console.log(`Created ${output}`);
console.log('Included Web2js runtime artifacts:');

for (const artifact of runtimeArtifacts) {
    const exists = files.has(artifact);
    console.log(`  ${exists ? '✓' : '-'} ${artifact}`);
}
