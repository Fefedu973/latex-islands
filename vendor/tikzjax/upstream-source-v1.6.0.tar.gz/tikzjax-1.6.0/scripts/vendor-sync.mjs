#!/usr/bin/env node

import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import vendorConfig from '../vendor.config.mjs';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(scriptDir, '..');
const vendorRoot = path.resolve(projectRoot, vendorConfig.vendorDir);
const statePath = path.resolve(projectRoot, vendorConfig.stateFile);

const command = process.argv[2] || 'sync';
const force = process.argv.includes('--force');
const noBuild = process.argv.includes('--no-build');

const toPosix = (value) => value.split(path.sep).join('/');

const formatBytes = (bytes) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KiB`;
    return `${(bytes / 1024 ** 2).toFixed(1)} MiB`;
};

const hashBuffer = (value) => crypto.createHash('sha256').update(value).digest('hex');

const listPathEntries = (absolutePath, logicalPath) => {
    if (!fs.existsSync(absolutePath)) {
        return [{ logicalPath, type: 'missing', absolutePath }];
    }

    const stat = fs.lstatSync(absolutePath);

    if (stat.isSymbolicLink()) {
        return [
            {
                logicalPath,
                type: 'symlink',
                absolutePath,
                linkTarget: fs.readlinkSync(absolutePath)
            }
        ];
    }

    if (stat.isFile()) {
        return [{ logicalPath, type: 'file', absolutePath }];
    }

    if (!stat.isDirectory()) {
        return [{ logicalPath, type: 'other', absolutePath }];
    }

    const entries = [];
    const children = fs.readdirSync(absolutePath).sort((a, b) => a.localeCompare(b));

    for (const child of children) {
        const childAbsolute = path.join(absolutePath, child);
        const childLogical = `${logicalPath}/${child}`;
        entries.push(...listPathEntries(childAbsolute, childLogical));
    }

    if (entries.length === 0) {
        entries.push({ logicalPath, type: 'directory', absolutePath });
    }

    return entries;
};

const hashPaths = (root, pathsToHash) => {
    const hash = crypto.createHash('sha256');

    for (const relativePath of [...pathsToHash].sort((a, b) => a.localeCompare(b))) {
        const absolutePath = path.resolve(root, relativePath);
        const entries = listPathEntries(absolutePath, toPosix(relativePath));

        for (const entry of entries) {
            hash.update(`${entry.type}:${entry.logicalPath}\0`);

            if (entry.type === 'file') {
                hash.update(fs.readFileSync(entry.absolutePath));
            } else if (entry.type === 'symlink') {
                hash.update(entry.linkTarget);
            }
        }
    }

    return hash.digest('hex');
};

const hashDirectory = (directory) => {
    if (!fs.existsSync(directory)) return null;
    return hashPaths(directory, ['.']);
};

const readState = () => {
    if (!fs.existsSync(statePath)) return { projects: {} };

    try {
        const value = JSON.parse(fs.readFileSync(statePath, 'utf8'));
        if (!value || typeof value !== 'object') return { projects: {} };
        if (!value.projects || typeof value.projects !== 'object') value.projects = {};
        return value;
    } catch {
        return { projects: {} };
    }
};

const writeState = (state) => {
    fs.mkdirSync(path.dirname(statePath), { recursive: true });
    fs.writeFileSync(statePath, `${JSON.stringify(state, null, 4)}\n`);
};

const requiredDistStatus = (project, localRoot) => {
    const distRoot = path.resolve(localRoot, project.dist);
    const missing = [];

    for (const required of project.requiredDist || []) {
        if (!fs.existsSync(path.resolve(distRoot, required))) {
            missing.push(required);
        }
    }

    return { distRoot, missing };
};

const readProjectVersion = (localRoot) => {
    const packagePath = path.join(localRoot, 'package.json');
    if (!fs.existsSync(packagePath)) return null;

    try {
        const packageData = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
        return packageData.version || null;
    } catch {
        return null;
    }
};

const runBuild = (project, localRoot) => {
    if (!project.build?.command) {
        throw new Error(`${project.name}: no build command is configured.`);
    }

    console.log(`↻ ${project.name}: sources changed -> building`);

    const result = spawnSync(project.build.command, project.build.args || [], {
        cwd: localRoot,
        env: process.env,
        stdio: 'inherit'
    });

    if (result.error) {
        throw result.error;
    }

    if (result.status !== 0) {
        throw new Error(`${project.name}: build failed with exit code ${result.status}.`);
    }
};

const copyVendor = (distRoot, destination) => {
    fs.rmSync(destination, { recursive: true, force: true });
    fs.mkdirSync(path.dirname(destination), { recursive: true });
    fs.cpSync(distRoot, destination, { recursive: true, force: true });
};

const printInspectFiles = (project, localRoot) => {
    if (!project.inspectFiles?.length) return true;

    let ok = true;
    console.log('  Web2js handoff files:');

    for (const relativePath of project.inspectFiles) {
        const absolutePath = path.resolve(localRoot, relativePath);

        if (!fs.existsSync(absolutePath) || !fs.statSync(absolutePath).isFile()) {
            console.log(`    ! ${relativePath}: missing`);
            ok = false;
            continue;
        }

        const content = fs.readFileSync(absolutePath);
        const sha256 = hashBuffer(content);
        console.log(`    ✓ ${relativePath}: ${formatBytes(content.length)} sha256=${sha256}`);
    }

    return ok;
};

const ensureProjectRoot = (project) => {
    const localRoot = path.resolve(projectRoot, project.local);

    if (!fs.existsSync(localRoot) || !fs.statSync(localRoot).isDirectory()) {
        throw new Error(`${project.name}: local project not found: ${localRoot}`);
    }

    return localRoot;
};

const sync = () => {
    const state = readState();
    let builtCount = 0;
    let copiedCount = 0;
    let reusedCount = 0;

    console.log('Vendor sync');
    console.log('===========');

    for (const project of vendorConfig.projects) {
        const localRoot = ensureProjectRoot(project);
        let sourceHash = hashPaths(localRoot, project.inputs || []);
        let { distRoot, missing } = requiredDistStatus(project, localRoot);
        const previous = state.projects[project.name];

        const needsBuild = force || !previous || previous.sourceHash !== sourceHash || missing.length > 0;

        if (needsBuild) {
            if (noBuild) {
                const reason = missing.length > 0 ? `missing dist files: ${missing.join(', ')}` : 'source inputs changed';
                throw new Error(`${project.name}: ${reason}; --no-build prevents rebuilding.`);
            }

            runBuild(project, localRoot);
            builtCount += 1;
            sourceHash = hashPaths(localRoot, project.inputs || []);
            ({ distRoot, missing } = requiredDistStatus(project, localRoot));

            if (missing.length > 0) {
                throw new Error(`${project.name}: build completed but dist is incomplete: ${missing.join(', ')}`);
            }
        } else {
            console.log(`✓ ${project.name}: unchanged -> build skipped`);
            reusedCount += 1;
        }

        const distHash = hashDirectory(distRoot);
        const destination = path.resolve(vendorRoot, project.name);
        const vendorHash = hashDirectory(destination);

        if (distHash !== vendorHash) {
            copyVendor(distRoot, destination);
            copiedCount += 1;
            console.log(`  ✓ synced ${toPosix(path.relative(projectRoot, destination))}`);
        } else {
            console.log('  ✓ vendor already synchronized');
        }

        state.projects[project.name] = {
            sourceHash,
            distHash,
            version: readProjectVersion(localRoot)
        };
    }

    writeState(state);

    console.log('');
    console.log(`${builtCount} built, ${reusedCount} reused, ${copiedCount} vendor copies updated.`);
};

const check = () => {
    const state = readState();
    let ok = true;

    console.log('Vendor check');
    console.log('============');

    for (const project of vendorConfig.projects) {
        const localRoot = ensureProjectRoot(project);
        const sourceHash = hashPaths(localRoot, project.inputs || []);
        const { distRoot, missing } = requiredDistStatus(project, localRoot);
        const destination = path.resolve(vendorRoot, project.name);
        const previous = state.projects[project.name];
        const version = readProjectVersion(localRoot);

        console.log(`${project.name}${version ? ` ${version}` : ''}`);
        console.log(`  source: ${toPosix(path.relative(projectRoot, localRoot)) || '.'}`);

        if (missing.length > 0) {
            console.log(`  ! dist incomplete: ${missing.join(', ')}`);
            ok = false;
        } else {
            console.log('  ✓ dist complete');
        }

        if (!previous) {
            console.log('  ! no vendor-sync state yet');
            ok = false;
        } else if (previous.sourceHash !== sourceHash) {
            console.log('  ! source inputs changed since last sync');
            ok = false;
        } else {
            console.log('  ✓ source inputs unchanged since last sync');
        }

        if (missing.length === 0) {
            const distHash = hashDirectory(distRoot);
            const vendorHash = hashDirectory(destination);

            if (!vendorHash) {
                console.log('  ! vendor copy missing');
                ok = false;
            } else if (distHash !== vendorHash) {
                console.log('  ! vendor copy differs from dist');
                ok = false;
            } else {
                console.log('  ✓ vendor copy matches dist');
            }
        }

        if (!printInspectFiles(project, localRoot)) {
            console.log('  ! one or more Web2js handoff files are missing');
            ok = false;
        }

        console.log('');
    }

    if (!ok) {
        process.exitCode = 1;
        return;
    }

    console.log('✓ Vendors are current.');
};

const clean = () => {
    fs.rmSync(vendorRoot, { recursive: true, force: true });
    fs.rmSync(statePath, { force: true });

    const stateDir = path.dirname(statePath);
    if (fs.existsSync(stateDir) && fs.readdirSync(stateDir).length === 0) {
        fs.rmdirSync(stateDir);
    }

    console.log(`Removed ${toPosix(path.relative(projectRoot, vendorRoot))} and vendor-sync state.`);
};

try {
    if (command === 'sync') {
        sync();
    } else if (command === 'check') {
        check();
    } else if (command === 'clean') {
        clean();
    } else {
        console.error(`Unknown vendor command: ${command}`);
        console.error('Use: sync, check, or clean.');
        process.exitCode = 1;
    }
} catch (error) {
    console.error(`Vendor ${command} failed: ${error.message}`);
    process.exitCode = 1;
}
